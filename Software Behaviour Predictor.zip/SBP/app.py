from flask import Flask, render_template, request
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
from sklearn.preprocessing import MultiLabelBinarizer
import pickle
import os

# Initialize app
app = Flask(__name__)

# Load model and tools
model = load_model("lstm_model.h5")
with open("tokenizer.pkl", "rb") as f:
    tokenizer = pickle.load(f)
with open("label_binarizer.pkl", "rb") as f:
    mlb = pickle.load(f)

# Prediction route
@app.route("/", methods=["GET", "POST"])
def index():
    predicted_labels = []
    accuracy = None

    if request.method == "POST":
        text = request.form.get("description")
        if text:
            sequence = tokenizer.texts_to_sequences([text])
            padded_sequence = tf.keras.preprocessing.sequence.pad_sequences(sequence, maxlen=100)
            prediction = model.predict(padded_sequence)
            predicted_labels = mlb.inverse_transform(np.round(np.array(prediction)))[0]
            accuracy = np.mean(np.round(prediction) == (prediction > 0.5))

    return render_template("index.html", predicted_labels=predicted_labels, accuracy=accuracy)

# Run server
if __name__ == "__main__":
    app.run(debug=True)
