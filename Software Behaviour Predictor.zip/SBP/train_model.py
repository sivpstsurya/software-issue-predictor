import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MultiLabelBinarizer
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense
from tensorflow.keras.models import save_model
import pickle

# Load the dataset (corrected filename with space)
df = pd.read_csv("final dataset.csv")  # ✅ Make sure this file is in the same folder as this script

# Prepare data
texts = df["report"].astype(str).tolist()
labels = df.drop("report", axis=1)
label_names = labels.columns
labels = labels.values

# Tokenize text
max_words = 10000
max_len = 100

tokenizer = Tokenizer(num_words=max_words, oov_token="<OOV>")
tokenizer.fit_on_texts(texts)
sequences = tokenizer.texts_to_sequences(texts)
X = pad_sequences(sequences, maxlen=max_len)

# Binarize labels
mlb = MultiLabelBinarizer(classes=label_names.tolist())
Y = mlb.fit_transform([tuple([label_names[i] for i, val in enumerate(row) if val == 1]) for row in labels])

# Split data
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=42)

# Build LSTM model
model = Sequential([
    Embedding(input_dim=max_words, output_dim=64, input_length=max_len),
    LSTM(64, return_sequences=False),
    Dense(len(label_names), activation='sigmoid')
])

model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
model.summary()

# Train model
model.fit(X_train, Y_train, epochs=5, batch_size=32, validation_data=(X_test, Y_test))

# Evaluate model
loss, accuracy = model.evaluate(X_test, Y_test)
print(f"\n✅ Model Accuracy on Test Set: {accuracy:.2f}")

# Save the model, tokenizer, and label binarizer
model.save("lstm_model.h5")
with open("tokenizer.pkl", "wb") as f:
    pickle.dump(tokenizer, f)

with open("label_binarizer.pkl", "wb") as f:
    pickle.dump(mlb, f)

print("✅ Model, tokenizer, and label binarizer saved successfully.")
